function validateForm() {
  $first_name = $last_name = $email = $phone_number = $address_1 =
   $address_2 = $suburb = $state = $zip = $comment = "";
    var q = document.forms["Form"]["first_name"].value;
    var w = document.forms["Form"]["last_name"].value;
    var e = document.forms["Form"]["email"].value;
    var r = document.forms["Form"]["phone_number"].value;
    var t = document.forms["Form"]["address_1"].value;
    var y = document.forms["Form"]["address_2"].value;
    var u = document.forms["Form"]["suburb"].value;
    var i = document.forms["Form"]["state"].value;
    var o = document.forms["Form"]["zip"].value;
    var a = document.forms["Form"]["comment"].value;
    if ( q == "") {
        alert("first_name must be filled out");
        return false;
    } else ( w == "") {
        alert("last_name must be filled out");
        return false;
    } else ( e == "") {
        alert("email must be filled out");
        return false;
    } else ( r == "") {
        alert(" phone number must be filled out");
        return false;
    } else ( t == "") {
        alert(" Address 1 must be filled out");
        return false;
    } else ( y == "") {
        alert(" Address 2 must be filled out");
        return false;
    } else ( u == "") {
        alert(" Suburb must be filled out");
        return false;
    } else (i  == "") {
        alert(" State must be filled out");
        return false;
    } else ( o == "") {
        alert(" zip must be filled out");
        return false;
    } else ( a == "") {
        alert(" Comment must be filled out");
        return false;
    }else {
        return true
    }      
}
